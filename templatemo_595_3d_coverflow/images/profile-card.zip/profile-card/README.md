# Profile Card

A Pen created on CodePen.

Original URL: [https://codepen.io/Beni70/pen/OJVwmVQ](https://codepen.io/Beni70/pen/OJVwmVQ).

Responsive and colorful Profile Card concept. 