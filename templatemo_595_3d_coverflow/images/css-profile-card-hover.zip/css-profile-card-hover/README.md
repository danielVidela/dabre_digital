# CSS Profile Card Hover

A Pen created on CodePen.

Original URL: [https://codepen.io/cjr85/pen/WNjNryx](https://codepen.io/cjr85/pen/WNjNryx).

CSS Profile Card with Hover effect - Basic HTML/CSS